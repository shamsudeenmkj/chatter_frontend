import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';

const API = 'https://chatter-backend-4i7g.onrender.com';

/* ─── helpers ─────────────────────────────────────────────────────────────── */
const authHeaders = () => ({
  'Content-Type': 'application/json',
  Authorization: `Bearer ${localStorage.getItem('token')}`,
});

const fmt = (iso) => {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit',
    });
  } catch { return '—'; }
};

const NAV_ITEMS = [
  ['overview', '⬡', 'Overview'],
  ['users', '◈', 'Users'],
  ['chats', '◎', 'Direct Chats'],
  ['public', '◉', 'Public Feed'],
  ['groups', '⬡', 'Groups'],
  ['meetings', '◆', 'Meetings'],
  ['outlook', '◇', 'Outlook Events'],
  ['polls', '◈', 'Polls'],
];

const TITLES = {
  overview: 'Overview', users: 'Users', chats: 'Direct Chats', public: 'Public Feed',
  groups: 'Groups', meetings: 'Meetings', outlook: 'Outlook Events', polls: 'Polls',
};

const ROLES = ['manager', 'developer', 'designer', 'qa', 'hr', 'sales', 'other'];
const LOCATIONS = ['mumbai', 'chennai'];

/* ─── small UI atoms ──────────────────────────────────────────────────────── */
const Tag = ({ label, color }) => (
  <span style={{
    display: 'inline-block', padding: '2px 8px', borderRadius: 999,
    fontSize: 11, fontWeight: 700, color, background: `${color}1A`,
  }}>{label}</span>
);

const ActionBtn = ({ label, color, onClick }) => (
  <button onClick={onClick} style={{
    border: `1px solid ${color}33`, background: `${color}10`, color,
    borderRadius: 6, padding: '4px 10px', fontSize: 11, fontWeight: 700,
    cursor: 'pointer', marginRight: 6,
  }}>{label}</button>
);

const Empty = ({ text }) => (
  <div style={{ padding: 40, textAlign: 'center', color: '#94A3B8', fontSize: 13 }}>{text}</div>
);

const Th = ({ children }) => (
  <th style={{
    textAlign: 'left', padding: '10px 14px', fontSize: 11, fontWeight: 800,
    letterSpacing: 0.6, color: '#64748B', borderBottom: '1px solid #E2E8F0',
    background: '#F8FAFC', textTransform: 'uppercase', whiteSpace: 'nowrap',
  }}>{children}</th>
);
const Td = ({ children, mono }) => (
  <td style={{
    padding: '10px 14px', fontSize: 12.5, color: '#0F172A', borderBottom: '1px solid #F1F5F9',
    fontFamily: mono ? 'monospace' : undefined, whiteSpace: 'nowrap',
  }}>{children}</td>
);

const Input = (props) => (
  <input {...props} style={{
    height: 36, borderRadius: 8, border: '1px solid #E2E8F0', padding: '0 10px',
    fontSize: 12.5, outline: 'none', ...props.style,
  }} />
);
const Select = ({ value, onChange, options, style }) => (
  <select value={value} onChange={onChange} style={{
    height: 36, borderRadius: 8, border: '1px solid #E2E8F0', padding: '0 8px',
    fontSize: 12.5, background: '#fff', ...style,
  }}>
    {options.map((o) => <option key={o} value={o}>{o}</option>)}
  </select>
);

/* ─── main component ──────────────────────────────────────────────────────── */
const AdminPanel = () => {
  const navigate = useNavigate();
  const [tab, setTab] = useState('overview');
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState(null);
  const [toast, setToast] = useState(null);

  const [users, setUsers] = useState([]);
  const [meetings, setMeetings] = useState([]);
  const [outlook, setOutlook] = useState([]);
  const [convs, setConvs] = useState([]);
  const [groups, setGroups] = useState([]);
  const [polls, setPolls] = useState([]);
  const [pubMsgs, setPubMsgs] = useState([]);

  const [selConv, setSelConv] = useState(null);
  const [msgs, setMsgs] = useState([]);
  const [selGrp, setSelGrp] = useState(null);
  const [grpMsgs, setGrpMsgs] = useState([]);
  const [msgLoading, setMsgLoading] = useState(false);

  // filters
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState('All');
  const [userLocFilter, setUserLocFilter] = useState('All');
  const [meetingSearch, setMeetingSearch] = useState('');
  const [meetingStatusFilter, setMeetingStatusFilter] = useState('All');
  const [meetingHostFilter, setMeetingHostFilter] = useState('All');
  const [outlookSearch, setOutlookSearch] = useState('');

  // user form
  const [showUserForm, setShowUserForm] = useState(false);
  const [editUser, setEditUser] = useState(null);
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'developer', location: 'chennai', isAdmin: false });
  const [pwdTarget, setPwdTarget] = useState(null);
  const [newPwd, setNewPwd] = useState('');

  const showToast = (text, isError) => {
    setToast({ text, isError });
    setTimeout(() => setToast(null), 3000);
  };

  const load = useCallback(async () => {
    setLoading(true);
    setApiError(null);
    try {
      if (['overview', 'users', 'meetings', 'outlook', 'groups', 'polls'].includes(tab)) {
        const r = await fetch(`${API}/admin/users`, { headers: authHeaders() });
        const d = await r.json();
        if (!d.success) throw new Error(d.message || 'Failed to load users');
        setUsers(d.users || []);
      }
      if (['overview', 'meetings'].includes(tab)) {
        const r = await fetch(`${API}/admin/meetings`, { headers: authHeaders() });
        const d = await r.json();
        if (!d.success) throw new Error(d.message || 'Failed to load meetings');
        setMeetings(d.meetings || []);
      }
      if (['overview', 'outlook'].includes(tab)) {
        const r = await fetch(`${API}/admin/outlook`, { headers: authHeaders() });
        const d = await r.json();
        if (!d.success) throw new Error(d.message || 'Failed to load Outlook events');
        setOutlook(d.events || []);
      }
      if (tab === 'chats') {
        const r = await fetch(`${API}/admin/conversations`, { headers: authHeaders() });
        const d = await r.json();
        if (!d.success) throw new Error(d.message || 'Failed to load conversations');
        setConvs((d.conversations || []).filter((c) => c.type === 'direct'));
        setSelConv(null); setMsgs([]);
      }
      if (tab === 'groups') {
        const r = await fetch(`${API}/admin/conversations`, { headers: authHeaders() });
        const d = await r.json();
        if (!d.success) throw new Error(d.message || 'Failed to load groups');
        setGroups((d.conversations || []).filter((c) => c.type === 'group'));
        setSelGrp(null); setGrpMsgs([]);
      }
      if (['overview', 'polls'].includes(tab)) {
        const r = await fetch(`${API}/polls`, { headers: authHeaders() });
        const d = await r.json();
        if (d.success) setPolls(d.polls || []);
      }
      if (tab === 'public') {
        const r = await fetch(`${API}/admin/messages/public`, { headers: authHeaders() });
        const d = await r.json();
        if (!d.success) throw new Error(d.message || 'Failed to load public messages');
        setPubMsgs(d.messages || []);
      }
    } catch (e) {
      setApiError(e.message);
      showToast(`Error: ${e.message}`, true);
    }
    setLoading(false);
  }, [tab]);

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [tab]);

  const userName = (id) => users.find((u) => u._id === id)?.name || (id || '').slice(0, 6);

  /* ── filtered lists ──────────────────────────────────────────────────── */
  const filteredUsers = useMemo(() => {
    const q = userSearch.toLowerCase();
    return users.filter((u) =>
      (!q || (u.name || '').toLowerCase().includes(q) || (u.email || '').toLowerCase().includes(q)) &&
      (userRoleFilter === 'All' || u.role === userRoleFilter) &&
      (userLocFilter === 'All' || u.location === userLocFilter));
  }, [users, userSearch, userRoleFilter, userLocFilter]);

  const filteredMeetings = useMemo(() => {
    const q = meetingSearch.toLowerCase();
    return meetings.filter((m) => {
      const hostName = userName(m.hostId).toLowerCase();
      const matchQ = !q || (m.title || '').toLowerCase().includes(q) ||
        (m.roomId || '').toLowerCase().includes(q) || hostName.includes(q);
      const matchStatus = meetingStatusFilter === 'All' ||
        (meetingStatusFilter === 'Active' && m.isActive) ||
        (meetingStatusFilter === 'Done' && !m.isActive);
      const matchHost = meetingHostFilter === 'All' || m.hostId === meetingHostFilter;
      return matchQ && matchStatus && matchHost;
    });
  }, [meetings, meetingSearch, meetingStatusFilter, meetingHostFilter, users]);

  const filteredOutlook = useMemo(() => {
    const q = outlookSearch.toLowerCase();
    return outlook.filter((e) => {
      const uName = userName(e.userId).toLowerCase();
      return !q || (e.subject || '').toLowerCase().includes(q) || uName.includes(q);
    });
  }, [outlook, outlookSearch, users]);

  /* ── actions ──────────────────────────────────────────────────────────── */
  const openMeetingReport = (roomId) => navigate(`/meeting-details/${roomId}`);

  const delMeeting = async (roomId) => {
    if (!window.confirm(`Delete meeting room "${roomId}"? This cannot be undone.`)) return;
    try {
      const r = await fetch(`${API}/admin/meetings/${roomId}`, { method: 'DELETE', headers: authHeaders() });
      const d = await r.json();
      if (!d.success) throw new Error(d.message || 'Delete failed');
      showToast('Meeting deleted');
      load();
    } catch (e) { showToast(e.message, true); }
  };

  const delOutlookEvent = async (id) => {
    if (!window.confirm('Delete this Outlook event?')) return;
    try {
      await fetch(`${API}/admin/outlook/${id}`, { method: 'DELETE', headers: authHeaders() });
      showToast('Event deleted');
      load();
    } catch (e) { showToast(e.message, true); }
  };

  const delPoll = async (pollId) => {
    if (!window.confirm('Delete this poll?')) return;
    try {
      const r = await fetch(`${API}/polls/${pollId}`, { method: 'DELETE', headers: authHeaders() });
      const d = await r.json();
      if (!d.success) throw new Error(d.message || 'Only the creator can delete this poll');
      showToast('Poll deleted');
      load();
    } catch (e) { showToast(e.message, true); }
  };

  const delPublicMessage = async (messageId) => {
    if (!window.confirm('Delete this message for everyone?')) return;
    try {
      await fetch(`${API}/admin/messages/${messageId}`, { method: 'DELETE', headers: authHeaders() });
      showToast('Message deleted');
      load();
    } catch (e) { showToast(e.message, true); }
  };

  const delGroup = async (conversationId) => {
    if (!window.confirm('Delete this group and all its messages?')) return;
    try {
      await fetch(`${API}/admin/conversations/${conversationId}`, { method: 'DELETE', headers: authHeaders() });
      showToast('Group deleted');
      load();
    } catch (e) { showToast(e.message, true); }
  };

  const openConvMsgs = async (convId, isGroup) => {
    setMsgLoading(true);
    if (isGroup) setSelGrp(convId); else setSelConv(convId);
    try {
      const r = await fetch(`${API}/admin/messages/${convId}`, { headers: authHeaders() });
      const d = await r.json();
      if (isGroup) setGrpMsgs(d.messages || []); else setMsgs(d.messages || []);
    } catch { /* ignore */ }
    setMsgLoading(false);
  };

  const delAnyMessage = async (messageId, isGroup) => {
    if (!window.confirm('Delete this message?')) return;
    await fetch(`${API}/admin/messages/${messageId}`, { method: 'DELETE', headers: authHeaders() });
    if (isGroup) openConvMsgs(selGrp, true); else openConvMsgs(selConv, false);
  };

  const resetForm = () => setForm({ name: '', email: '', password: '', role: 'developer', location: 'chennai', isAdmin: false });

  const openCreateUser = () => { setEditUser(null); resetForm(); setShowUserForm(true); };
  const openEditUser = (u) => {
    setEditUser(u);
    setForm({ name: u.name || '', email: u.email || '', password: '', role: u.role || 'developer', location: u.location || 'chennai', isAdmin: !!u.isAdmin });
    setShowUserForm(true);
  };

  const saveUser = async () => {
    try {
      if (editUser) {
        const r = await fetch(`${API}/admin/users/${editUser._id}`, {
          method: 'PUT', headers: authHeaders(),
          body: JSON.stringify({ name: form.name, email: form.email, role: form.role, location: form.location, isAdmin: form.isAdmin }),
        });
        const d = await r.json();
        if (!d.success) throw new Error(d.message || 'Update failed');
        showToast('User updated');
      } else {
        const r = await fetch(`${API}/admin/users`, {
          method: 'POST', headers: authHeaders(),
          body: JSON.stringify(form),
        });
        const d = await r.json();
        if (!d.success) throw new Error(d.message || 'Create failed');
        showToast('User created');
      }
      setShowUserForm(false);
      load();
    } catch (e) { showToast(e.message, true); }
  };

  const delUser = async (id) => {
    if (!window.confirm('Delete this user account?')) return;
    try {
      const r = await fetch(`${API}/admin/users/${id}`, { method: 'DELETE', headers: authHeaders() });
      const d = await r.json();
      if (!d.success) throw new Error(d.message || 'Delete failed');
      showToast('User deleted');
      load();
    } catch (e) { showToast(e.message, true); }
  };

  const savePassword = async () => {
    if (!newPwd || newPwd.length < 6) { showToast('Password must be at least 6 characters', true); return; }
    try {
      const r = await fetch(`${API}/admin/users/${pwdTarget._id}/password`, {
        method: 'PUT', headers: authHeaders(), body: JSON.stringify({ password: newPwd }),
      });
      const d = await r.json();
      if (!d.success) throw new Error(d.message || 'Failed to reset password');
      showToast('Password reset');
      setPwdTarget(null); setNewPwd('');
    } catch (e) { showToast(e.message, true); }
  };

  /* ── styles ───────────────────────────────────────────────────────────── */
  const st = {
    root: { display: 'flex', height: '100vh', fontFamily: 'Montserrat, sans-serif', background: '#F5F7FB' },
    sidebar: { width: 220, background: '#0F172A', display: 'flex', flexDirection: 'column', flexShrink: 0 },
    sidebarHead: { padding: '24px 20px 16px', borderBottom: '1px solid #1E293B' },
    nav: (active) => ({
      display: 'flex', alignItems: 'center', gap: 12, padding: '12px 20px', cursor: 'pointer',
      background: active ? '#1E293B' : 'transparent',
      borderRight: active ? '3px solid #6366F1' : '3px solid transparent',
      color: active ? '#F1F5F9' : '#64748B', fontSize: 12, fontWeight: 700, letterSpacing: 0.8,
    }),
    main: { flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 },
    topbar: {
      height: 56, background: '#fff', borderBottom: '1px solid #E2E8F0', display: 'flex',
      alignItems: 'center', padding: '0 24px', boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
    },
    body: { flex: 1, overflow: 'auto', padding: 20 },
    card: { background: '#fff', borderRadius: 10, boxShadow: '0 1px 6px rgba(0,0,0,0.08)', overflow: 'hidden' },
    btn: { height: 36, borderRadius: 8, border: '1px solid #E2E8F0', background: '#fff', color: '#475569', fontSize: 12, fontWeight: 700, padding: '0 14px', cursor: 'pointer' },
    btnPrimary: { height: 36, borderRadius: 8, border: 'none', background: '#004ECC', color: '#fff', fontSize: 12, fontWeight: 700, padding: '0 16px', cursor: 'pointer' },
    filterBar: { display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 12, alignItems: 'center' },
    statGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px,1fr))', gap: 14 },
    statCard: { background: '#fff', borderRadius: 10, padding: 18, boxShadow: '0 1px 6px rgba(0,0,0,0.08)' },
  };

  /* ── renderers per-tab ───────────────────────────────────────────────── */
  const renderOverview = () => (
    <div style={st.statGrid}>
      {[
        ['Users', users.length, '#004ECC'],
        ['Meetings', meetings.length, '#6366F1'],
        ['Outlook Events', outlook.length, '#0EA5E9'],
        ['Polls', polls.length, '#10B981'],
      ].map(([label, val, color]) => (
        <div key={label} style={st.statCard}>
          <p style={{ fontSize: 11, fontWeight: 700, color: '#64748B', letterSpacing: 0.6, textTransform: 'uppercase' }}>{label}</p>
          <p style={{ fontSize: 28, fontWeight: 800, color, marginTop: 6 }}>{val}</p>
        </div>
      ))}
    </div>
  );

  const renderUsers = () => (
    <>
      <div style={st.filterBar}>
        <Input placeholder="Search name, email…" value={userSearch} onChange={(e) => setUserSearch(e.target.value)} style={{ width: 220 }} />
        <Select value={userRoleFilter} onChange={(e) => setUserRoleFilter(e.target.value)} options={['All', ...ROLES]} />
        <Select value={userLocFilter} onChange={(e) => setUserLocFilter(e.target.value)} options={['All', ...LOCATIONS]} />
        <button style={st.btn} onClick={() => { setUserSearch(''); setUserRoleFilter('All'); setUserLocFilter('All'); }}>Clear</button>
        <span style={{ fontSize: 12, color: '#94A3B8' }}>{filteredUsers.length} / {users.length}</span>
        <div style={{ flex: 1 }} />
        <button style={st.btnPrimary} onClick={openCreateUser}>+ New User</button>
      </div>
      <div style={st.card}>
        {filteredUsers.length === 0 ? <Empty text="No users match filters" /> : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead><tr>{['NAME', 'EMAIL', 'ROLE', 'LOCATION', 'ADMIN', 'ACTIONS'].map((h) => <Th key={h}>{h}</Th>)}</tr></thead>
            <tbody>
              {filteredUsers.map((u) => (
                <tr key={u._id}>
                  <Td>{u.name}</Td>
                  <Td>{u.email}</Td>
                  <Td><Tag label={u.role} color="#6366F1" /></Td>
                  <Td>{u.location}</Td>
                  <Td>{u.isAdmin ? <Tag label="Admin" color="#10B981" /> : '—'}</Td>
                  <Td>
                    <ActionBtn label="Edit" color="#0EA5E9" onClick={() => openEditUser(u)} />
                    <ActionBtn label="Reset Pwd" color="#F59E0B" onClick={() => setPwdTarget(u)} />
                    <ActionBtn label="Delete" color="#EF4444" onClick={() => delUser(u._id)} />
                  </Td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );

  const renderMeetings = () => (
    <>
      <div style={st.filterBar}>
        <Input placeholder="Search title, room, host…" value={meetingSearch} onChange={(e) => setMeetingSearch(e.target.value)} style={{ width: 220 }} />
        <Select value={meetingStatusFilter} onChange={(e) => setMeetingStatusFilter(e.target.value)} options={['All', 'Active', 'Done']} />
        <Select value={meetingHostFilter} onChange={(e) => setMeetingHostFilter(e.target.value)} options={['All', ...users.map((u) => u._id)]} />
        <button style={st.btn} onClick={() => { setMeetingSearch(''); setMeetingStatusFilter('All'); setMeetingHostFilter('All'); }}>Clear</button>
        <span style={{ fontSize: 12, color: '#94A3B8' }}>{filteredMeetings.length} / {meetings.length}</span>
      </div>
      <div style={st.card}>
        {filteredMeetings.length === 0 ? <Empty text="No meetings match filters" /> : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead><tr>{['TITLE', 'ROOM ID', 'HOST', 'SCHEDULED', 'DURATION', 'STATUS', 'ACTIONS'].map((h) => <Th key={h}>{h}</Th>)}</tr></thead>
            <tbody>
              {filteredMeetings.map((m) => (
                <tr key={m.roomId}>
                  <Td>{m.title || '—'}</Td>
                  <Td mono>{m.roomId}</Td>
                  <Td>{userName(m.hostId)}</Td>
                  <Td>{m.scheduledAt ? fmt(m.scheduledAt) : 'Instant'}</Td>
                  <Td><Tag label={`${m.durationMinutes || 60}m`} color="#6366F1" /></Td>
                  <Td><Tag label={m.isActive ? 'Active' : 'Done'} color={m.isActive ? '#10B981' : '#94A3B8'} /></Td>
                  <Td>
                    <ActionBtn label="Report" color="#004ECC" onClick={() => openMeetingReport(m.roomId)} />
                    <ActionBtn label="Delete" color="#EF4444" onClick={() => delMeeting(m.roomId)} />
                  </Td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );

  const renderOutlook = () => (
    <>
      <div style={st.filterBar}>
        <Input placeholder="Search subject, user…" value={outlookSearch} onChange={(e) => setOutlookSearch(e.target.value)} style={{ width: 240 }} />
        <span style={{ fontSize: 12, color: '#94A3B8' }}>{filteredOutlook.length} / {outlook.length}</span>
      </div>
      <div style={st.card}>
        {filteredOutlook.length === 0 ? <Empty text="No Outlook events found" /> : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead><tr>{['SUBJECT', 'USER', 'START', 'END', 'ACTIONS'].map((h) => <Th key={h}>{h}</Th>)}</tr></thead>
            <tbody>
              {filteredOutlook.map((e) => (
                <tr key={e._id}>
                  <Td>{e.subject || '—'}</Td>
                  <Td>{userName(e.userId)}</Td>
                  <Td>{fmt(e.start)}</Td>
                  <Td>{fmt(e.end)}</Td>
                  <Td><ActionBtn label="Delete" color="#EF4444" onClick={() => delOutlookEvent(e._id)} /></Td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );

  const renderPolls = () => (
    <div style={st.card}>
      {polls.length === 0 ? <Empty text="No polls found" /> : (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead><tr>{['TITLE', 'CREATOR', 'AUDIENCE', 'VOTES', 'CREATED', 'ACTIONS'].map((h) => <Th key={h}>{h}</Th>)}</tr></thead>
          <tbody>
            {polls.map((p) => (
              <tr key={p.pollId}>
                <Td>{p.title}</Td>
                <Td>{p.creatorName}</Td>
                <Td><Tag label={p.audienceType} color="#0EA5E9" /></Td>
                <Td>{(p.options || []).reduce((a, o) => a + (o.votes || []).length, 0)}</Td>
                <Td>{fmt(p.createdAt)}</Td>
                <Td><ActionBtn label="Delete" color="#EF4444" onClick={() => delPoll(p.pollId)} /></Td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );

  const renderPublic = () => (
    <div style={st.card}>
      {pubMsgs.length === 0 ? <Empty text="No public messages" /> : (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead><tr>{['FROM', 'CONTENT', 'SENT', 'ACTIONS'].map((h) => <Th key={h}>{h}</Th>)}</tr></thead>
          <tbody>
            {pubMsgs.map((m) => (
              <tr key={m.messageId}>
                <Td>{m.fromName}</Td>
                <Td style={{ maxWidth: 320 }}>{m.kind === 'text' ? m.content : `[${m.kind}] ${m.fileName || ''}`}</Td>
                <Td>{fmt(m.sentAt)}</Td>
                <Td><ActionBtn label="Delete" color="#EF4444" onClick={() => delPublicMessage(m.messageId)} /></Td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );

  const renderMsgList = (list, isGroup) => (
    <div style={{ ...st.card, marginTop: 12, maxHeight: 360, overflow: 'auto' }}>
      {msgLoading ? <Empty text="Loading messages…" /> : list.length === 0 ? <Empty text="No messages" /> : (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead><tr>{['FROM', 'CONTENT', 'SENT', 'ACTIONS'].map((h) => <Th key={h}>{h}</Th>)}</tr></thead>
          <tbody>
            {list.map((m) => (
              <tr key={m.messageId}>
                <Td>{m.fromName}</Td>
                <Td style={{ maxWidth: 320 }}>{m.kind === 'text' ? m.content : `[${m.kind}] ${m.fileName || ''}`}</Td>
                <Td>{fmt(m.sentAt)}</Td>
                <Td><ActionBtn label="Delete" color="#EF4444" onClick={() => delAnyMessage(m.messageId, isGroup)} /></Td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );

  const renderChats = () => (
    <>
      <div style={st.card}>
        {convs.length === 0 ? <Empty text="No direct conversations" /> : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead><tr>{['MEMBERS', 'UPDATED', 'ACTIONS'].map((h) => <Th key={h}>{h}</Th>)}</tr></thead>
            <tbody>
              {convs.map((c) => (
                <tr key={c.conversationId} style={{ background: selConv === c.conversationId ? '#F0F6FF' : undefined }}>
                  <Td>{(c.memberNames || []).join(' ↔ ')}</Td>
                  <Td>{fmt(c.updatedAt)}</Td>
                  <Td><ActionBtn label="View" color="#0EA5E9" onClick={() => openConvMsgs(c.conversationId, false)} /></Td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      {selConv && renderMsgList(msgs, false)}
    </>
  );

  const renderGroups = () => (
    <>
      <div style={st.card}>
        {groups.length === 0 ? <Empty text="No groups" /> : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead><tr>{['GROUP', 'MEMBERS', 'UPDATED', 'ACTIONS'].map((h) => <Th key={h}>{h}</Th>)}</tr></thead>
            <tbody>
              {groups.map((g) => (
                <tr key={g.conversationId} style={{ background: selGrp === g.conversationId ? '#F0F6FF' : undefined }}>
                  <Td>{g.groupName}</Td>
                  <Td>{(g.memberNames || []).length} members</Td>
                  <Td>{fmt(g.updatedAt)}</Td>
                  <Td>
                    <ActionBtn label="View" color="#0EA5E9" onClick={() => openConvMsgs(g.conversationId, true)} />
                    <ActionBtn label="Delete" color="#EF4444" onClick={() => delGroup(g.conversationId)} />
                  </Td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      {selGrp && renderMsgList(grpMsgs, true)}
    </>
  );

  const renderBody = () => {
    switch (tab) {
      case 'overview': return renderOverview();
      case 'users': return renderUsers();
      case 'meetings': return renderMeetings();
      case 'outlook': return renderOutlook();
      case 'polls': return renderPolls();
      case 'public': return renderPublic();
      case 'chats': return renderChats();
      case 'groups': return renderGroups();
      default: return null;
    }
  };

  return (
    <div style={st.root}>
      {/* sidebar */}
      <div style={st.sidebar}>
        <div style={st.sidebarHead}>
          <span style={{ fontSize: 15, fontWeight: 900, letterSpacing: 2, fontFamily: 'monospace' }}>
            <span style={{ color: '#F1F5F9' }}>CTRL</span><span style={{ color: '#6366F1' }}>PANEL</span>
          </span>
        </div>
        {NAV_ITEMS.map(([id, icon, label]) => (
          <div key={id} style={st.nav(tab === id)} onClick={() => setTab(id)}>
            <span style={{ fontSize: 14 }}>{icon}</span>{label}
          </div>
        ))}
        <div style={{ flex: 1 }} />
        <div style={{ padding: 16, borderTop: '1px solid #1E293B', display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#10B981', boxShadow: '0 0 6px #10B981' }} />
          <span style={{ fontSize: 11, color: '#64748B' }}>Admin Session Active</span>
        </div>
      </div>

      {/* main */}
      <div style={st.main}>
        <div style={st.topbar}>
          <span style={{ fontSize: 15, fontWeight: 800, letterSpacing: 1.2, color: '#0F172A' }}>{TITLES[tab]}</span>
          <div style={{ flex: 1 }} />
          {loading && <span style={{ fontSize: 12, color: '#94A3B8', marginRight: 12 }}>Loading…</span>}
          <button style={{ ...st.btn, marginRight: 10 }} onClick={load}>↻ Refresh</button>
          <button style={st.btn} onClick={() => navigate(-1)}>← Back</button>
        </div>
        <div style={st.body}>
          {apiError && (
            <div style={{ background: '#FEF2F2', color: '#B91C1C', padding: '10px 14px', borderRadius: 8, fontSize: 12.5, marginBottom: 12 }}>
              {apiError}
            </div>
          )}
          {renderBody()}
        </div>
      </div>

      {/* toast */}
      {toast && (
        <div style={{
          position: 'fixed', bottom: 24, right: 24, background: toast.isError ? '#EF4444' : '#0F172A',
          color: '#fff', padding: '10px 16px', borderRadius: 8, fontSize: 12.5, boxShadow: '0 4px 14px rgba(0,0,0,0.2)',
        }}>{toast.text}</div>
      )}

      {/* user form modal */}
      {showUserForm && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50 }}>
          <div style={{ background: '#fff', borderRadius: 12, padding: 24, width: 360 }}>
            <h3 style={{ fontSize: 15, fontWeight: 800, marginBottom: 14 }}>{editUser ? 'Edit User' : 'New User'}</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <Input placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              <Input placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              {!editUser && <Input placeholder="Password" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />}
              <Select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} options={ROLES} />
              <Select value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} options={LOCATIONS} />
              <label style={{ fontSize: 12.5, display: 'flex', alignItems: 'center', gap: 8 }}>
                <input type="checkbox" checked={form.isAdmin} onChange={(e) => setForm({ ...form, isAdmin: e.target.checked })} />
                Grant admin access
              </label>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 18 }}>
              <button style={st.btn} onClick={() => setShowUserForm(false)}>Cancel</button>
              <button style={st.btnPrimary} onClick={saveUser}>Save</button>
            </div>
          </div>
        </div>
      )}

      {/* reset password modal */}
      {pwdTarget && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50 }}>
          <div style={{ background: '#fff', borderRadius: 12, padding: 24, width: 320 }}>
            <h3 style={{ fontSize: 15, fontWeight: 800, marginBottom: 14 }}>Reset password for {pwdTarget.name}</h3>
            <Input placeholder="New password (min 6 chars)" type="password" value={newPwd} onChange={(e) => setNewPwd(e.target.value)} style={{ width: '100%' }} />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 18 }}>
              <button style={st.btn} onClick={() => { setPwdTarget(null); setNewPwd(''); }}>Cancel</button>
              <button style={st.btnPrimary} onClick={savePassword}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;